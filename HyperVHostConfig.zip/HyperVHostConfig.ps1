<# 
Microsoft Azure Meetup Dubai : AzureMigrateDay
.File Name
 - HyperVHostConfig.ps1
 
.What calls this script?
 - This is a PowerShell DSC script called by OnPremPrimarySite.json

.What does this script do?  
 - Creates an Internal Switch in Hyper-V called "Nat Switch"
    
 - Downloads an Image of an Ubuntu Linux 16.04 Server to the local drive

 - Add a new IP address to the Internal Network for Hyper-V attached to the NAT Switch

 - Creates a NAT Network on 192.168.0.0/24

 - Creates the Virtual Machine in Hyper-V

 - Issues a Start Command for the new "OnPremVM"
#>

Configuration Main
{
	Param ( [string] $nodeName )

	Import-DscResource -ModuleName 'PSDesiredStateConfiguration', 'xHyper-V'

	node $nodeName
  	{
		# Ensures a VM with default settings
        xVMSwitch InternalSwitch
        {
            Ensure         = 'Present'
            Name           = 'Nat Switch'
            Type           = 'Internal'
        }
		
		Script ConfigureHyperV
    	{
			GetScript = 
			{
				@{Result = "ConfigureHyperV"}
			}	
		
			TestScript = 
			{
           		return $false
        	}	
		
			SetScript =
			{
				New-Item C:\LabVMs -ItemType directory
					$DBBlobUri = 'https://azuremeetupdubai.blob.core.windows.net/labvhds/DBServer.vhdx'
					$WebBlobUri = 'https://azuremeetupdubai.blob.core.windows.net/labvhds/WebServer.vhdx'
					$Sas = '?sv=2017-11-09&ss=b&srt=sco&sp=rwdlac&se=2018-10-30T22:30:00Z&st=2018-10-29T14:30:00Z&spr=https&sig=v0FT4jTh%2BwISp%2B3cV%2B2YvdQrV9xizBvwDgqqMwGreQc%3D'
					$DBOutputPath = 'C:\LabVMs\DBServer.vhdx'
					$WebOutputpath ='C:\LabVMs\WebServer.vhdx'
					$DBFullUri = "$DBBlobUri$Sas"
					$WebFullUri = "$WebBlobUri$Sas"
						(New-Object System.Net.WebClient).DownloadFile($DBFullUri, $DBOutputPath)
						(New-Object System.Net.WebClient).DownloadFile($WebFullUri, $WebOutputPath)				

							$NatSwitch = Get-NetAdapter -Name "vEthernet (NAT Switch)"
							New-NetIPAddress -IPAddress 192.168.0.1 -PrefixLength 24 -InterfaceIndex $NatSwitch.ifIndex
							New-NetNat -Name NestedVMNATnetwork -InternalIPInterfaceAddressPrefix 192.168.0.0/24 -Verbose
							New-VM -Name DBServer1 -MemoryStartupBytes 2GB -BootDevice VHD -VHDPath 'C:\LabVMs\DBServer.vhdx' -Path 'C:\' -Generation 1 -Switch "NAT Switch"
								Start-VM -Name DBServer1
							New-VM -Name WebServer1 -MemoryStartupBytes 2GB -BootDevice VHD -VHDPath 'C:\LabVMs\WebServer.vhdx' -Path 'C:\' -Generation 1 -Switch "NAT Switch"
								Start-VM -Name Webserver1


			}
		}	
  	}
}