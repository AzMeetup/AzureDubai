<# 
Microsoft Azure Meetup Dubai : AzureMigrateDay
.File Name
 - HyperVHostConfig.ps1
 
.What calls this script?
 - This is a PowerShell DSC script called by OnPremPrimarySite.json

.What does this script do?  
 - Creates an Internal Switch in Hyper-V called "Nat Switch"
    
 - Downloads an Image of an Ubuntu Linux 16.04 Server to the local drive

 - Add a new IP address to the Internal Network for Hyper-V attached to the NAT Switch

 - Creates a NAT Network on 192.168.0.0/24

 - Creates the Virtual Machine in Hyper-V

 - Issues a Start Command for the new "OnPremVM"
#>

Configuration Main
{
	Param ( [string] $nodeName )

	Import-DscResource -ModuleName 'PSDesiredStateConfiguration', 'xHyper-V'

	node $nodeName
  	{
		# Ensures a VM with default settings
        xVMSwitch InternalSwitch
        {
            Ensure         = 'Present'
            Name           = 'Nat Switch'
            Type           = 'Internal'
        }
		
		Script ConfigureHyperV
    	{
			GetScript = 
			{
				@{Result = "ConfigureHyperV"}
			}	
		
			TestScript = 
			{
           		return $false
        	}	
		
			SetScript =
			{
				New-Item C:\LabVMs -ItemType directory
				$url = "https://azcopy.azureedge.net/azcopy-8-1-0/MicrosoftAzureStorageAzCopy_netcore_x64.msi"
				$output = "C:\LabVMs\azcopy.msi"
				$wc = New-Object System.Net.WebClient
				$wc.DownloadFile($url, $output)
				Start-Process msiexec.exe -Wait -ArgumentList '/I C:\LabVMs\azcopy.msi /quiet'
				cd 'C:\Program Files (x86)\Microsoft SDKs\Azure\AzCopy\'
				.\AzCopy.exe /Source:https://azuremeetupdubai.blob.core.windows.net/labvhds /Dest:C:\labvms /SourceKey:m1NxLXh8fvJatPmOfN3YtlffTzzeacn5p2MgUcd6oQWMqbkGg9JR5OU1pepoF6XlvUZRv6lboU959PmX8ERZuQ== /S 
				
							$NatSwitch = Get-NetAdapter -Name "vEthernet (NAT Switch)"
							New-NetIPAddress -IPAddress 192.168.0.1 -PrefixLength 24 -InterfaceIndex $NatSwitch.ifIndex
							New-NetNat -Name NestedVMNATnetwork -InternalIPInterfaceAddressPrefix 192.168.0.0/24 -Verbose
							New-VM -Name DBServer1 -MemoryStartupBytes 2GB -BootDevice VHD -VHDPath 'C:\LabVMs\DBServer.vhdx' -Path 'C:\' -Generation 1 -Switch "NAT Switch"
								Start-VM -Name DBServer1
							New-VM -Name WebServer1 -MemoryStartupBytes 2GB -BootDevice VHD -VHDPath 'C:\LabVMs\WebServer.vhdx' -Path 'C:\' -Generation 1 -Switch "NAT Switch"
								Start-VM -Name Webserver1


			}
		}	
  	}
}